# secrets.py
# ==========
# Copy this file to your Pico W. Fill in all REPLACE_ME values before deploying.
#
# HOW TO FIND EACH VALUE:
#
#   WIFI_SSID / WIFI_PASSWORD:
#     Your home Wi-Fi network name and password.
#
#   FIREBASE_API_KEY:
#     Firebase Console → Project Settings → General →
#     "Your apps" section → Web API Key
#
#   FIREBASE_EMAIL:
#     The email you used when creating the Pico device account in
#     Firebase Console → Authentication → Users
#     (e.g. "pico-device@letitrain.local")
#
#   FIREBASE_PASSWORD:
#     The password you set for the Pico device account.
#     Use a strong random 40+ character string.
#
#   FIREBASE_DB_URL:
#     Firebase Console → Realtime Database → Data tab →
#     The URL shown at the top, e.g. "https://letitrain-default-rtdb.firebaseio.com"
#     Include https://, no trailing slash.
#
#   FIREBASE_DEVICE_ID:
#     The key under /devices/ in your Firebase schema.
#     Leave as "pico-zone-1" unless you changed the schema.
#
#   FIRMWARE_VERSION:
#     Update this string whenever you flash new firmware.

WIFI_SSID     = "REPLACE_ME"
WIFI_PASSWORD = "REPLACE_ME"

FIREBASE_API_KEY    = "REPLACE_ME"   # AIzaSy...
FIREBASE_EMAIL      = "REPLACE_ME"   # pico-device@letitrain.local
FIREBASE_PASSWORD   = "REPLACE_ME"   # 40-char random string
FIREBASE_DB_URL     = "REPLACE_ME"   # https://your-project-default-rtdb.firebaseio.com
FIREBASE_DEVICE_ID  = "pico-zone-1"

FIRMWARE_VERSION = "1.1.0"
